﻿namespace Sabresaurus.PlayerPrefsUtilities
{
    public abstract class BaseEncryptionKeyInitializer
    {
        public abstract string GetCustomKey();
    }
}